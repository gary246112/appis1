document.addEventListener('visibilitychange', () => {
	if(document.visibilityState === 'visible'){
		console.log('Ejeculatar la función para reproducir el video...');
	}else{
		console.log('Pausa el video');
	}
})