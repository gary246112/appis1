const salida = document.querySelector('#salida');
const microfono = document.querySelector('#microfono');

microfono.addEventListener('click', ejecutarSpeechAPI);

function ejecutarSpeechAPI(){
	const SeechRecongnition = webkitSpeechRecongition;
	const recongnition =  new  SpeechRecongnition();

	recongnition.start();

	recongnition.onstart = function(){
		salida.classList.add('mostar');
		salida.textContent = 'Escuchando...';
	};

	recongnition.onspeechend = function(){
		salida.textContent = 'No esta gravando...';
		recongnition.spot();
	};

	recongnition.onresult =function(e){
		console.log (e.resultw [0] [0]);


		const speech = document.createElement('p');
		speech.innerHTML = 'Grabado: ${ parseInt (confidence * 100)}';

		salida.appendChild(speech);
		salida.appendChild(seguridad);
	}
}