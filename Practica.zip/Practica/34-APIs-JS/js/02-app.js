document.addEventListener('DomContenLonaded',() => {
	const observer = new IntersectionOnserver( entries => {

		if(entries[0].isIntersecting){
			console.log('Ya esta visible');
		}
	}):
	observer.observer(document.querySelector('premiun'));
});