const notificarBtn = document.querySelector('#notificar');

notificarBtn.addEventListener('click',() => {
	.requestPermission()
	.then( resultado =>{
		console.log('Su resultdo es', resultdo);
	})
});

const verNotificacion = document.querySelector('#verNotificacion');
verNotificacion.addEventListener('click', () => {
	if(Notificacion.permission == 'granted') {
		const notificacion = new Notificacion('Ver la notificación', {
			icon:'img/ccj.png',
			body: 'Codigo con Estela, aprende proyectos'
		});

		notificación.onclink = function(){
			window.open('https://www.codigoconEstela.com')
		}
	}
});