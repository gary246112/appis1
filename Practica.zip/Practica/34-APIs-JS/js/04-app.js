const abrirBtn = document.querySeletor('#abrir-pantalla-completa');
const abrirBtn = document.querySeletor('#salir-pantalla-completa');

abrirBtn.addEventListener('click', pantallaCompleta);
abrirBtn.addEventListener('click', cerrarpantallaCompleta);

function pantallaCompleta(){
	document.documentElement.requesFullscreen();
}

function cerrarPantallaCompleta(){
	document.exitFullscreen();
}